// local_user.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';

// auth_provider.dart
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

// connection_provider.dart
import 'package:connectivity_plus/connectivity_plus.dart';
//import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';

// auth_text_field.dart
import 'package:flutter/material.dart';

// connection_status_bar.dart
import 'package:provider/provider.dart';

// main.dart
import 'package:firebase_core/firebase_core.dart';
import 'package:rent_a_house/services/firebase_options.dart';

// main.dart
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ConnectionProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()..initialize()),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
        initialRoute: '/auth',
        routes: {
          '/auth': (context) => const AuthScreen(),
          '/home': (context) => const HomeScreen(),
        },
        builder: (context, child) {
          return Consumer<AuthProvider>(
            builder: (context, auth, _) {
              if (auth.isLoading) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }

              final currentRoute = ModalRoute.of(context)?.settings.name;
              if (auth.isAuthenticated && currentRoute == '/auth') {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  Navigator.pushReplacementNamed(context, '/home');
                });
              } else if (!auth.isAuthenticated && currentRoute == '/home') {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  Navigator.pushReplacementNamed(context, '/auth');
                });
              }

              return child!;
            },
          );
        },
      ),
    );
  }
}

// app_constants.dart
class AppConstants {
  static const appName = 'Dual Auth Demo';

  // Auth Strings
  static const login = 'Login';
  static const register = 'Register';
  static const email = 'Email';
  static const password = 'Password';
  static const name = 'Name';
  static const phone = 'Phone';
  static const createAccount = 'Create new account';
  static const haveAccount = 'I already have an account';

  // Connection Strings
  static const online = 'Online';
  static const offline = 'Offline';
  static const wifi = 'WiFi';
  static const mobile = 'Mobile';
  static const noConnection = 'No Connection';

  // Home Strings
  static const apartments = 'Apartments';
  static const houses = 'Houses';
  static const beach = 'Beach';

  // Errors
  static const loginFailed = 'Login failed';
  static const registrationFailed = 'Registration failed';
  static const offlineRegistration =
      'Registration requires internet connection';
  static const weakPassword = 'Password must be at least 6 characters';
}

class FirebasePaths {
  static const users = 'users';
}

// local_user.dart

class LocalUser {
  final String? id;
  final String name;
  final String email;
  final String password;
  final String phone;

  LocalUser({
    this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.phone,
  });

  String get hashedPassword {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  Map<String, dynamic> toMap({bool forLocal = false}) {
    return {
      'id': id,
      'name': name,
      'email': email,
      'password': forLocal ? hashedPassword : password,
      'phone': phone,
    };
  }

  factory LocalUser.fromMap(Map<String, dynamic> map) {
    return LocalUser(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      password: map['password'],
      phone: map['phone'],
    );
  }
}

// auth_provider.dart

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final FirebaseDatabase _firebaseDatabase = FirebaseDatabase.instance;
  Database? _database;
  LocalUser? _currentUser;
  bool _isLoading = false;
  String? _error;

  LocalUser? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;

  Future<void> initialize() async {
    await _initDatabase();
    await _checkPersistedUser();
  }

  Future<void> _initDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'users.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE users(id TEXT PRIMARY KEY, name TEXT, email TEXT UNIQUE, password TEXT, phone TEXT)',
        );
      },
      version: 1,
    );
  }

  Future<void> _checkPersistedUser() async {
    final users = await _database?.query('users', limit: 1);
    if (users != null && users.isNotEmpty) {
      _currentUser = LocalUser.fromMap(users.first);
      notifyListeners();
    }
  }

  Future<bool> login(String email, String password) async {
    try {
      _setLoading(true);
      final hasConnection = await _checkInternetConnection();
      final user = await _authenticate(email, password, hasConnection);

      if (user != null) {
        _currentUser = user;
        await _persistUser(user);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError(AppConstants.loginFailed);
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> register(LocalUser user) async {
    try {
      _setLoading(true);
      final hasConnection = await _checkInternetConnection();
      if (!hasConnection) {
        _setError(AppConstants.offlineRegistration);
        return false;
      }

      final createdUser = await _createUser(user);
      if (createdUser != null) {
        _currentUser = createdUser;
        await _persistUser(createdUser);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> _checkInternetConnection() async {
    return await InternetConnection().hasInternetAccess;
  }

  Future<LocalUser?> _authenticate(
    String email,
    String password,
    bool isOnline,
  ) async {
    if (isOnline) {
      final credential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final snapshot =
          await _firebaseDatabase
              .ref()
              .child('${FirebasePaths.users}/${credential.user!.uid}')
              .get();

      if (snapshot.exists) {
        final data = snapshot.value as Map;
        return LocalUser(
          id: credential.user!.uid,
          name: data['name'],
          email: email,
          password: password,
          phone: data['phone'],
        );
      }
    } else {
      final users = await _database?.query(
        'users',
        where: 'email = ?',
        whereArgs: [email],
      );

      if (users != null && users.isNotEmpty) {
        final user = LocalUser.fromMap(users.first);
        if (user.hashedPassword ==
            LocalUser(
              email: email,
              password: password,
              name: user.name,
              phone: user.phone,
            ).hashedPassword) {
          return user;
        }
      }
    }
    return null;
  }

  Future<LocalUser?> _createUser(LocalUser user) async {
    final credential = await _firebaseAuth.createUserWithEmailAndPassword(
      email: user.email,
      password: user.password,
    );

    await _firebaseDatabase
        .ref()
        .child('${FirebasePaths.users}/${credential.user!.uid}')
        .set({'name': user.name, 'email': user.email, 'phone': user.phone});

    return LocalUser(
      id: credential.user!.uid,
      name: user.name,
      email: user.email,
      password: user.password,
      phone: user.phone,
    );
  }

  Future<void> _persistUser(LocalUser user) async {
    await _database?.insert(
      'users',
      user.toMap(forLocal: true),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  void logout() {
    _currentUser = null;
    _database?.delete('users');
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}

// connection_provider.dart
class ConnectionProvider with ChangeNotifier {
  ConnectivityResult _connectionType = ConnectivityResult.none;
  bool _isConnected = false;

  ConnectivityResult get connectionType => _connectionType;
  bool get isConnected => _isConnected;
  bool get isWifi => _connectionType == ConnectivityResult.wifi;
  bool get isMobile => _connectionType == ConnectivityResult.mobile;
  bool get isOffline => !_isConnected;

  ConnectionProvider() {
    _init();
  }

  Future<void> _init() async {
    Connectivity().onConnectivityChanged.listen((result) {
      _connectionType = result as ConnectivityResult;
      notifyListeners();
    });

    InternetConnection().onStatusChange.listen((status) {
      _isConnected = status == InternetStatus.connected;
      notifyListeners();
    });

    _connectionType =
        (await Connectivity().checkConnectivity()) as ConnectivityResult;
    _isConnected = await InternetConnection().hasInternetAccess;
  }

  Future<bool> checkConnection() async {
    _isConnected = await InternetConnection().hasInternetAccess;
    notifyListeners();
    return _isConnected;
  }

  String get connectionStatus {
    if (!_isConnected) return AppConstants.offline;
    if (isWifi) return AppConstants.wifi;
    if (isMobile) return AppConstants.mobile;
    return AppConstants.noConnection;
  }
}

// auth_text_field.dart

class AuthTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscureText;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final Widget? suffixIcon;

  const AuthTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.icon,
    this.obscureText = false,
    this.keyboardType,
    this.validator,
    this.suffixIcon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: const OutlineInputBorder(),
          suffixIcon: suffixIcon,
        ),
        validator: validator,
      ),
    );
  }
}

// connection_status_bar.dart

class ConnectionStatusBar extends StatelessWidget {
  const ConnectionStatusBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ConnectionProvider>(
      builder: (context, connection, _) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 4),
          color: connection.isConnected ? Colors.green[100] : Colors.red[100],
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                connection.isConnected ? Icons.wifi : Icons.signal_wifi_off,
                size: 18,
                color: connection.isConnected ? Colors.green : Colors.red,
              ),
              const SizedBox(width: 8),
              Text(
                connection.connectionStatus,
                style: TextStyle(
                  color: connection.isConnected ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// auth_screen.dart
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _phoneController = TextEditingController();

  bool isLogin = true;
  bool _visible = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _toggleAuthMode() {
    // Removed redundant 'as BuildContext' cast
    Provider.of<AuthProvider>(
      context, // context is a member variable of _AuthScreenState
      listen: false,
    ).clearError();
    setState(() {
      isLogin = !isLogin;
      _nameController.clear();
      _phoneController.clear();
    });
  }

  //===============================================================================Erro de context antes do BuildContext
  //Analisar
  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();

    // Removed redundant 'as BuildContext' cast
    final auth = Provider.of<AuthProvider>(
      context, // context is a member variable of _AuthScreenState
      listen: false,
    );
    setState(() => _isLoading = true);

    // Consider returning a more detailed result from auth.login/register
    // so you can display specific error messages from the backend.
    final success =
        isLogin
            ? await auth.login(_emailController.text, _passwordController.text)
            : await auth.register(
              LocalUser(
                name: _nameController.text,
                email: _emailController.text,
                password: _passwordController.text,
                phone: _phoneController.text,
              ),
            );

    setState(() => _isLoading = false);

    // If 'success' is false, it's assumed 'auth.error' will be set by AuthProvider
    // and displayed in the UI.
    if (success && mounted) {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  //Analisar
  //===============================================================================Erro de context antes do BuildContext
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final connection = Provider.of<ConnectionProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(isLogin ? AppConstants.login : AppConstants.register),
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const ConnectionStatusBar(),
                    if (!isLogin)
                      AuthTextField(
                        controller: _nameController,
                        label: AppConstants.name,
                        icon: Icons.person,
                        validator:
                            (value) => value!.isEmpty ? 'Required' : null,
                      ),
                    AuthTextField(
                      controller: _emailController,
                      label: AppConstants.email,
                      icon: Icons.email,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value!.isEmpty) return 'Required';
                        if (!value.contains('@')) return 'Invalid email';
                        return null;
                      },
                    ),
                    AuthTextField(
                      controller: _passwordController,
                      label: AppConstants.password,
                      icon: Icons.lock,
                      obscureText: _visible,
                      suffixIcon: IconButton(
                        icon: Icon(
                          _visible ? Icons.visibility : Icons.visibility_off,
                        ),
                        onPressed: () => setState(() => _visible = !_visible),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) return 'Required';
                        if (!isLogin && value.length < 6) {
                          return AppConstants.weakPassword;
                        }
                        return null;
                      },
                    ),
                    if (!isLogin)
                      AuthTextField(
                        controller: _phoneController,
                        label: AppConstants.phone,
                        icon: Icons.phone,
                        keyboardType: TextInputType.phone,
                        validator:
                            (value) => value!.isEmpty ? 'Required' : null,
                      ),
                    const SizedBox(height: 20),
                    if (auth.error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          auth.error!,
                          style: const TextStyle(color: Colors.red),
                        ),
                      ),
                    ElevatedButton(
                      onPressed: _isLoading ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: Text(
                        isLogin ? AppConstants.login : AppConstants.register,
                      ),
                    ),
                    TextButton(
                      onPressed: _isLoading ? null : _toggleAuthMode,
                      child: Text(
                        isLogin
                            ? AppConstants.createAccount
                            : AppConstants.haveAccount,
                        style: const TextStyle(color: Colors.blue),
                      ),
                    ),
                    if (!isLogin && connection.isOffline)
                      const Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Text(
                          AppConstants.offlineRegistration,
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          if (_isLoading) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}

// home_screen.dart

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _categories = [
    AppConstants.apartments,
    AppConstants.houses,
    AppConstants.beach,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final connection = Provider.of<ConnectionProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          connection.isConnected ? AppConstants.online : AppConstants.offline,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).logout();
              Navigator.pushReplacementNamed(context, '/auth');
            },
          ),
        ],
        bottom:
            connection.isConnected
                ? TabBar(
                  controller: _tabController,
                  tabs: _categories.map((e) => Tab(text: e)).toList(),
                )
                : null,
      ),
      body: Column(
        children: [
          const ConnectionStatusBar(),
          Expanded(
            child:
                connection.isConnected
                    ? _buildOnlineContent()
                    : _buildOfflineContent(connection),
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineContent() {
    return TabBarView(
      controller: _tabController,
      children:
          _categories.map((category) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _getEmoji(category),
                    style: const TextStyle(fontSize: 60),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    category,
                    style: const TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Content for $category category',
                    style: const TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            );
          }).toList(),
    );
  }

  Widget _buildOfflineContent(ConnectionProvider connection) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.signal_wifi_off, size: 60, color: Colors.red),
            const SizedBox(height: 20),
            const Text(
              AppConstants.offline,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'Limited functionality available',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 40),
            ..._buildActionButtons(),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              onPressed: () async => await connection.checkConnection(),
              icon: const Icon(Icons.refresh),
              label: const Text('Check Connection'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildActionButtons() {
    return [
      _buildActionButton('Action 1', Icons.save),
      _buildActionButton('Action 2', Icons.history),
      _buildActionButton('Action 3', Icons.settings),
    ];
  }

  Widget _buildActionButton(String text, IconData icon) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
      child: ElevatedButton.icon(
        onPressed: () {},
        icon: Icon(icon),
        label: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text(text, style: const TextStyle(fontSize: 18)),
        ),
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }

  String _getEmoji(String category) {
    switch (category) {
      case AppConstants.apartments:
        return '🏢';
      case AppConstants.houses:
        return '🏠';
      case AppConstants.beach:
        return '🏖️';
      default:
        return '🏠';
    }
  }
}
